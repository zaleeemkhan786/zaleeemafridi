
# SRT to Audio generator for Video Dubbing in differente language
## Using Openai Whisper,Edge TTs & ffmpeg
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/NeuralFalconYT/SRT-2-AUDIO/blob/main/Multilingual_Dubbing_from_Subtitle.ipynb) <br>
## Using Openai Whisper X,Edge TTs & ffmpeg
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/NeuralFalconYT/SRT-2-AUDIO/blob/main/Whisperx_%26_Edge_TTS.ipynb) <br>
